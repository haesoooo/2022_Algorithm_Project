//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define ID_SCALE_NORMAL                 40001
#define ID_SCALE_RANK                   40002
#define ID_SCALE_LINEAR                 40003
#define ID_MUTATE_EX                    40004
#define ID_MUTATE_SM                    40005
#define ID_MUTATE_IM                    40006
#define ID_MUTATION_DM                  40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
